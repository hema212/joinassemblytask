package com.assembly;

import org.testng.annotations.Test;

import com.google.common.io.Files;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class WebAutomation {
	public WebDriver driver;
	String baseurl = "https://joinassembly.com/";

	// Setup webdriver
	@BeforeTest
	public void driverSetup() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hema_ramakrishna\\Chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	// Testcase to find whether the user has logged onto proper webpage application
	@Test(priority = 0)
	public void joinAssemblyPageTest() {
		driver.get(baseurl);
		String actual_title = driver.getTitle();
		String expected_title = "Free Employee Recognition Software with Slack Integration | Assembly";
		Assert.assertEquals(actual_title, expected_title);
		System.out.println("Assert passed");
	}

	/*
	 * Testcase to verify the count of email fields and click on second email field
	 * (If exists) Provide 2 different test data abc@gmail.com & abc@carrothr.com
	 * and check the response
	 */
	@Test(priority = 1)
	public void WebAppElementValidation() throws IOException, InterruptedException {
		int emailFieldCount = driver.findElements(By.xpath("//input[@type='email']")).size();
		System.out.println("The total count of email fields are " + emailFieldCount);
		WebElement secondEmailLocator = driver.findElement(By.xpath(
				"//form[@class='form-inline justify-content-center pt-20 pb-15 register_form register_form_light']/div/input"));
		secondEmailLocator.sendKeys("abc@gmail.com");
		WebElement TryButton = driver.findElement(By.xpath(
				"//form[@class='form-inline justify-content-center pt-20 pb-15 register_form register_form_light']/div/span[2]"));
		TryButton.click();
		String capturedResponse = driver.findElement(By.xpath(
				"//form[@class='form-inline justify-content-center pt-20 pb-15 register_form register_form_light register_form_error']/div/input"))
				.getAttribute("placeholder");
		System.out.println("Response for invalid mailid is " + capturedResponse);
		if (capturedResponse != null) {
			secondEmailLocator.sendKeys("abc@carrothr.com");
			TryButton.click();
			WebElement value = driver.findElement(By.xpath(
					"//div[@class='MuiPaper-root MuiCard-root jss105 jss9 MuiPaper-elevation1 MuiPaper-rounded']"));
			System.out.println("Response for valid mailid is " + value.getText());
			driver.navigate().back();
			Thread.sleep(1000L);
		}
	}

	/*
	 * Testcase to verify the recognition content is active by default. On click of
	 * anniversary and birthday content, the respective list should be active making
	 * other lists inactive.
	 */
	@Test(priority = 2)
	public void FeatureClick() throws Exception {
		this.takeScreenShot(driver, "C:\\Users\\hema_ramakrishna\\WebTestScreenshot\\webpagescreenshot.png");
		driver.findElement(By.xpath("//a[contains(text(), 'Features')]")).click();
		WebElement elementList = driver.findElement(By.xpath("//ul[@class='nav nav-vertical']/li"));
		WebElement recognitionContent = driver.findElement(By.xpath("//ul[@class='nav nav-vertical']/li[1]/a"));
		Boolean recognitionActiveContent = recognitionContent.isEnabled();
		System.out.println("Is recognition content is active by default? " + recognitionActiveContent);
		Thread.sleep(1000L);
		WebElement anniversaryContent = driver.findElement(By.xpath("//ul[@class='nav nav-vertical']/li[2]/a"));
		anniversaryContent.click();
		Boolean anniversaryActiveContent = anniversaryContent.isEnabled();
		System.out.println("Is aniversary and birthday content active? " + anniversaryActiveContent);
		System.out.println("Is recognition content active? " + elementList.isSelected());
		Thread.sleep(1000L);
	}

	/*
	 * Testcase to verify the contact us by switching to frames and enter slack in
	 * input field and check the output
	 */
	@Test(priority = 3)
	public void ContactUs() throws Exception {
		Actions actions = new Actions(driver);
		actions.keyDown(Keys.CONTROL).sendKeys(Keys.END).perform();
		driver.findElement(By.xpath("//a[contains(text(), 'Contact Us')]")).click();
		Thread.sleep(1000L);
		driver.switchTo().frame(2);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath("//input[@placeholder='Search for articles...']"));
		js.executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(1000L);
		element.sendKeys("Slack");
		driver.findElement(By.xpath("//button[@aria-label='Submit search']")).click();
		this.takeScreenShot(driver, "C:\\Users\\hema_ramakrishna\\WebTestScreenshot\\slackResponse.png");
	}

	// TakesScreenshot Interface to capture the web page
	public void takeScreenShot(WebDriver webdriver, String filepath) throws IOException {
		TakesScreenshot screenshot = ((TakesScreenshot) webdriver);
		File srcfile = screenshot.getScreenshotAs(OutputType.FILE);
		File destfile = new File(filepath);
		Files.copy(srcfile, destfile);
	}

	// Quit driver
	@AfterTest
	public void closeDriver() {
		driver.quit();
	}
}